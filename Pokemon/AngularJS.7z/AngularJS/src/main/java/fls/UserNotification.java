package fls;


public class UserNotification {

  private String text;
  private UserNotifictionType type;

  public UserNotification(String text, UserNotifictionType type) {
    this.text = text;
    this.type = type;
  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public UserNotifictionType getType() {
    return type;
  }

  public void setType(UserNotifictionType type) {
    this.type = type;
  }

}
