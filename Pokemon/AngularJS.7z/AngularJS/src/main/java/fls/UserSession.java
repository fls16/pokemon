package fls;

import java.util.LinkedHashSet;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

@SessionScope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@Component
public class UserSession {

  private static final Logger LOG = LoggerFactory.getLogger(UserSession.class);

  private Set<UserNotification> messages = new LinkedHashSet<>();

  public UserSession() {
    LOG.debug("Created new usersession");
  }

  public void addNotificationInfo(final String text) {
    if (text == null) {
      throw new IllegalArgumentException();
    }
    messages.add(new UserNotification(text, UserNotifictionType.INFO));
  }

  public void addNotificationWarning(final String text) {
    if (text == null) {
      throw new IllegalArgumentException();
    }
    messages.add(new UserNotification(text, UserNotifictionType.DANGER));
  }

  public void addNotificationSuccess(final String text) {
    if (text == null) {
      throw new IllegalArgumentException();
    }
    messages.add(new UserNotification(text, UserNotifictionType.SUCCESS));
  }

  public Set<UserNotification> getMessages() {
    Set<UserNotification> result;
    if (messages.isEmpty()) {
      result = new LinkedHashSet<>();
    } else {
      result = messages;
      messages = new LinkedHashSet<>();
      LOG.debug("Current notifications: [" + result.size() + "]");
    }
    return result;
  }
}
