package fls.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
// @Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

  @Autowired
  private UserDetailsService userDetailsService;

  @Autowired
  private CustomPermissionEvaluator permissionEvaluator;

  @Autowired
  private SecurityHandler successHandler;

  @Autowired
  private CustomAccessDeniedHandler customAccessDeniedHandler;

  @Override
  public void configure(final AuthenticationManagerBuilder auth) throws Exception {
    auth.userDetailsService(userDetailsService).passwordEncoder(new BCryptPasswordEncoder());
  }

  @Override
  protected void configure(final HttpSecurity http) throws Exception {
    // http.authorizeRequests()
    // .antMatchers("/assets/**", "/js/**", "/css/**", "/webjars/**", "/actuator/*").permitAll()
    // .antMatchers("/login*", "/password/request", "/password/reset").anonymous().anyRequest()
    // .authenticated().and().formLogin().successHandler(successHandler) // .loginPage("/login")
    // .failureUrl("/login?error").usernameParameter("username").permitAll().and().logout()
    // .logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/login")
    // .invalidateHttpSession(true).deleteCookies("JSESSIONID").and().sessionManagement()
    // .invalidSessionUrl("/logout").and().exceptionHandling()
    // .accessDeniedHandler(customAccessDeniedHandler).and().rememberMe()
    // .rememberMeCookieName("fispmt-remember-me").tokenValiditySeconds(7 * 24 * 60 * 60);

    http.authorizeRequests().antMatchers("/css/**", "/js/**", "/images/**").permitAll()
        .antMatchers("/login*", "/").permitAll().anyRequest().authenticated().and().formLogin()
        .successHandler(successHandler)// .loginPage("/login")
        .defaultSuccessUrl("/users").failureUrl("/login?error").permitAll().and().logout()
        .logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/login")
        .invalidateHttpSession(true).deleteCookies("JSESSIONID").and().sessionManagement()
        .invalidSessionUrl("/logout").and().exceptionHandling()
        .accessDeniedHandler(customAccessDeniedHandler);

  }

  public MethodSecurityExpressionHandler methodSecurityExpressionHandler() {
    final DefaultMethodSecurityExpressionHandler handler =
        new DefaultMethodSecurityExpressionHandler();
    handler.setPermissionEvaluator(permissionEvaluator);
    return handler;
  }

  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

}
