package fls.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import fls.domain.User;
import fls.repository.UserRepository;
import fls.security.Role;

@Service
public class UserService {

  @Autowired
  private UserRepository userRepository;

  public User saveAndFlush(User user) {
    return userRepository.saveAndFlush(user);
  }

  public Optional<User> findById(Long id) {
    return userRepository.findById(id);
  }

  public Optional<User> findByUsername(String username) {
    return userRepository.findByUsername(username);
  }

  public List<User> findAll() {
    return userRepository.findAll();
  }

  public User create(String username, String passwordHash, String locale, String firstname, String lastname, String email, Role... roles) {
    User user = new User(username, passwordHash, locale, firstname, lastname, email);
    user.setRoles(Arrays.asList(roles));
    return userRepository.saveAndFlush(user);
  }

}
