package fls.security;

import java.io.Serializable;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import fls.domain.User;
import fls.service.UserService;

@Component
public class CustomPermissionEvaluator implements PermissionEvaluator {

  private static final Logger LOGGER = LoggerFactory.getLogger(CustomPermissionEvaluator.class);

  @Autowired
  private UserService userService;

  @Autowired
  private RoleService roleService;

  /**
   * Authorizes "hasPermission". Returns true, if the User has the needed ProjectRole in a specific
   * review. If projectRole = "anyRole", it is just checked, if the user is linked to the review.
   */
  @Override
  public boolean hasPermission(Authentication auth, Object targetDomainObject, Object permission) {
    if ((auth == null) || (targetDomainObject == null) || !(permission instanceof String)) {

      return false;
    }
    Optional<User> user = userService.findByUsername(auth.getName());
    if (!user.isPresent()) {

      LOGGER.warn("No user with username: " + auth.getName());
      return false;
    }

    // TODO
    return false;
  }

  @Override
  public boolean hasPermission(Authentication authentication, Serializable targetId,
      String targetType, Object permission) {
    return false;
  }

}
