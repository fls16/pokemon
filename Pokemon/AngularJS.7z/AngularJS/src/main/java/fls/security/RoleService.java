package fls.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

  @Autowired
  private RoleRepository roleRepository;

  public List<Role> findAll() {
    return roleRepository.findAll();
  }

  public Optional<Role> findById(Long id) {
    return roleRepository.findById(id);
  }

  public List<Role> findByIds(List<Long> ids) {
    return roleRepository.findAllById(ids);
  }

  public Optional<Role> findByName(String name) {
    return roleRepository.findByName(name);
  }

  public List<Role> findByNames(String... names) {
    List<Role> roles = new ArrayList<>();
    for (String name : names) {
      roleRepository.findByName(name).ifPresent(r -> roles.add(r));
    }
    return roles;
  }

  public Role saveAndFlush(Role role) {
    return roleRepository.saveAndFlush(role);
  }

  public void deleteById(Long id) {
    roleRepository.deleteById(id);
  }



}
