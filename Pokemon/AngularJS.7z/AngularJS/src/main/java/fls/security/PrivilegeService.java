package fls.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PrivilegeService {

  @Autowired
  private PrivilegeRepository privilegeRepository;

  public List<Privilege> findAll() {
    return privilegeRepository.findAll();
  }

  public Optional<Privilege> findById(Long id) {
    return privilegeRepository.findById(id);
  }

  public List<Privilege> findByIds(List<Long> ids) {
    return privilegeRepository.findAllById(ids);
  }

  public Optional<Privilege> findByName(String name) {
    return privilegeRepository.findByName(name);
  }

  public List<Privilege> findByNames(String... names) {
    List<Privilege> privileges = new ArrayList<>();
    for (String name : names) {
      privilegeRepository.findByName(name).ifPresent(p -> privileges.add(p));
    }
    return privileges;
  }

  public Privilege saveAndFlush(Privilege privilege) {
    return privilegeRepository.saveAndFlush(privilege);
  }

  public void delete(Privilege privilege) {
    privilegeRepository.delete(privilege);
  }

}
