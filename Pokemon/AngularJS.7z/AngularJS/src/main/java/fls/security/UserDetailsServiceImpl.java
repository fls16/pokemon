package fls.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import fls.domain.User;
import fls.service.UserService;

@Service
@Transactional
public class UserDetailsServiceImpl implements UserDetailsService {

  @Autowired
  private UserService userService;

  @Autowired
  private RoleService roleService;

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User user = userService.findByUsername(username)
        .orElseThrow(() -> new IllegalStateException("No user found: " + username));
    return new org.springframework.security.core.userdetails.User(user.getUsername(),
        user.getPasswordHash(), user.isEnabled(), true, true, true,
        getAuthorities(user.getRoles()));
  }

  private Collection<? extends GrantedAuthority> getAuthorities(Collection<Role> roles) {
    return getGrantedAuthorities(getPrivileges(roles));
  }

  private List<String> getPrivileges(Collection<Role> roles) {
    List<String> privilegesAsStrings = new ArrayList<>();
    List<Privilege> privileges = new ArrayList<>();
    for (Role role : roles) {
      privileges.addAll(role.getPrivileges());
    }
    for (Privilege privilege : privileges) {
      privilegesAsStrings.add(privilege.getName());
    }
    return privilegesAsStrings;
  }

  private List<GrantedAuthority> getGrantedAuthorities(List<String> privileges) {
    return privileges.stream().map(p -> new SimpleGrantedAuthority(p)).collect(Collectors.toList());
  }

}
