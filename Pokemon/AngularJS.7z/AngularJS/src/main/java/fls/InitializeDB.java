package fls;

import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import com.github.javafaker.Faker;
import com.github.javafaker.Name;
import fls.domain.User;
import fls.security.Privilege;
import fls.security.PrivilegeService;
import fls.security.Role;
import fls.security.RoleService;
import fls.service.UserService;

@Component
public class InitializeDB {

  private static final Logger LOGGER = LoggerFactory.getLogger(InitializeDB.class);

  @Autowired
  private UserService userService;

  @Autowired
  private PasswordEncoder passwordEncoder;

  @Autowired
  private PrivilegeService privilegeService;

  @Autowired
  private RoleService roleService;


  @PostConstruct
  public void init() {
    LOGGER.info("Started loading data..");

    Privilege users_login = privilegeService.saveAndFlush(new Privilege("USERS_LOGIN"));
    Privilege users_manage = privilegeService.saveAndFlush(new Privilege("USERS_MANAGE"));

    Role normal_user = roleService.saveAndFlush(new Role("NORMAL_USER", users_login));
    Role system_admin =
        roleService.saveAndFlush(new Role("SYSTEM_ADMIN", users_login, users_manage));

    LOGGER.info("Started loading userdata..");
    Faker faker = new Faker();
    for (int i = 0; i < 10; i++) {
      Name name = faker.name();
      String firstname = name.firstName();
      String lastname = name.lastName();
      String username = firstname + "." + lastname;
      userService.saveAndFlush(new User(username, passwordEncoder.encode(username), "de", firstname,
          lastname, username + "@gmail.com"));
      System.out.println(username);
    }
    LOGGER.info("Finished loading userdata..");


    LOGGER.info("Finished loading data");
  }

}
