package fls;

public enum UserNotifictionType {
  INFO, SUCCESS, DANGER
}
