package fls.security;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseStatus;
import fls.UserSession;

@Component
public class CustomAccessDeniedHandler implements AccessDeniedHandler {

  @Autowired
  private UserSession userSession;

  final Logger LOG = LoggerFactory.getLogger(CustomAccessDeniedHandler.class);

  @Override
  @ResponseStatus(HttpStatus.CONFLICT) // 409
  public void handle(final HttpServletRequest request, final HttpServletResponse response,
      final AccessDeniedException accessDeniedException) throws IOException, ServletException {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    if (auth != null) {
      LOG.warn("User: " + auth.getName() + " attempted to access the protected URL: "
          + request.getRequestURI());
    }
    String referer = request.getHeader("Referer");

    LOG.info("User: " + auth.getName() + " kam von der Seite [" + referer
        + "] und wollte zu der URL: " + request.getRequestURI());
    if (referer == null || referer.isEmpty()) {
      referer = request.getContextPath() + "/projects/list";
    } else {
      referer = request.getContextPath() + referer;
    }
    LOG.info("Referer = " + referer);
    userSession.addNotificationWarning(
        "Sie sind nicht berechtigt, auf die angeforderte Ressource zuzugreifen.");
    response.addHeader("notAllowed", "notAllowed");
    response.sendRedirect(referer);

  }
}
